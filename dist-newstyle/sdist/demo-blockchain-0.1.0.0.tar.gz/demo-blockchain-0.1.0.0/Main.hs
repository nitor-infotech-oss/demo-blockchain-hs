module Main where

import BlockChain

main :: IO ()
main = putStrLn "Hello, Haskell!"
